package cuentas;

/**
 * CCuenta es una clase que representa una cuenta bancaria con operaciones
 * tales como ingresar y retirar dinero
 * Además, permite guardar información personal del titular de la cuenta.
 * 
 * @author Alejandro Martínez
 */
public class CCuenta {

    /** Nombre del titular de la cuenta */
    private String nombre;
    
    /** Número de cuenta */
    private String cuenta;
    
    /**Saldo de la cuenta*/
    private double saldo;
    
    /**Tipo de interés de la cuenta */
    private double tipoInteres;

    /**
     * Constructor vacío de la clase CCuenta
     */
    public CCuenta()
    {
    }

    /**
     * Constructor con parámtros de la clases CCuenta
     * 
     * @param nom Nombre del títular
     * @param cue Número de cuenta
     * @param sal Saldo inicial
     * @param tipo Tipo de interés
     */
    public CCuenta(String nom, String cue, double sal, double tipo)
    {
        nombre =nom;
        cuenta=cue;
        saldo=sal;
    }

    /**
     * Obtiene el nombre del titular
     * 
     * @return nombre del titular
     */
    
    public String getNombre() {
		return nombre;
	}

    /**
     * Establece o cambia el nombre del titular
     * 
     * @param nombre nombre del titular
     */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/***
	 * Obtiene el número de cuenta
	 * 
	 * @return número de cuenta
	 */
	public String getCuenta() {
		return cuenta;
	}

	/**
	 * Establece o cambia el número de cuenta
	 * 
	 * @param cuenta número de cuenta
	 */
	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	/**
	 * Obtiene saldo actual de la cuenta
	 * 
	 * @return saldo de la cuenta
	 */
	public double getSaldo() {
		return saldo;
	}

	/***
	 * Establece o cambia el saldo de la cuenta
	 * 
	 * @param saldo cambio de saldo
	 */
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	/**
	 * Obtiene el tipo de interés
	 * 
	 * @return tipo de interés
	 */
	public double getTipoInterés() {
		return tipoInteres;
	}

	/**
	 * Establece o cambia el tipo de interés
	 * 
	 * @param tipoInterés nuevo tipo de interés
	 */
	public void setTipoInterés(double tipoInteres) {
		this.tipoInteres = tipoInteres;
	}

	/**
	 * Devuelve el saldo actual de la cuenta
	 * 
	 * @return saldo actual
	 */
	public double estado()
    {
        return saldo;
    }

	/**
	 * Ingresa una cantidad de dinero en la cuenta.
	 * 
	 * @param cantidad cantidad ingresada
	 * @throws Exception cuando la cantidad es negativa
	 */
    public void ingresar(double cantidad) throws Exception
    {
        if (cantidad<0)
            throw new Exception("No se puede ingresar una cantidad negativa");
        saldo = saldo + cantidad;
    }

    /**
     *  Retirar una cantidad de dinero de la cuenta
     *  
     * @param cantidad cantidad que se retira
     * @throws Exception cuando la cantidad es negativa o el saldo es insuficiente
     */
    public void retirar(double cantidad) throws Exception
    {
        if (cantidad <= 0)
            throw new Exception ("No se puede retirar una cantidad negativa");
        if (estado()< cantidad)
            throw new Exception ("No se hay suficiente saldo");
        saldo = saldo - cantidad;
    }
}
